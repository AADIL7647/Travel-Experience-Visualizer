// static/js/main.js - Travel Diary UI helpers

document.addEventListener('DOMContentLoaded', () => {
  // Confirm on trip deletes
  document.querySelectorAll('form[action*="/delete_trip"]').forEach(form => {
    form.addEventListener('submit', (e) => {
      if (!confirm('Delete this trip? This cannot be undone.')) e.preventDefault();
    });
  });

  // Tab animate (auth.html)
  let authTab = document.getElementById('authTab');
  if (authTab) {
    let links = authTab.querySelectorAll('.nav-link');
    links.forEach(link => {
      link.addEventListener('shown.bs.tab', () => {
        document.querySelectorAll('.tab-pane').forEach(tab => tab.classList.remove('animate-fadein'));
        let activePane = document.querySelector(authTab.querySelector('.nav-link.active').dataset.bsTarget);
        if (activePane) activePane.classList.add('animate-fadein');
      });
    });
  }

  // Toast notification system
  function showToast(message, type = 'notice', duration = 2400) {
    let toastId = 'toast-' + type;
    let old = document.getElementById(toastId);
    if (old) old.remove();
    let div = document.createElement('div');
    div.className = `toast-${type}`;
    div.id = toastId;
    div.innerHTML = message;
    document.body.appendChild(div);
    div.style.display = 'block';
    setTimeout(() => { div.style.opacity = '0'; setTimeout(()=>div.remove(),500); }, duration);
  }
  window.showToast = showToast;

  // Dark mode toggle
// main.js
let themeBtn = document.querySelector('.theme-toggle');
if (themeBtn) {
  themeBtn.addEventListener('click', () => {
    document.body.classList.toggle('dark-mode');
    localStorage.setItem('theme', document.body.classList.contains('dark-mode') ? 'dark' : 'light');
    window.showToast(document.body.classList.contains('dark-mode') ? "Dark mode enabled" : "Light mode enabled", "notice");
  });
  // On page load, apply saved theme
  if (localStorage.getItem('theme') === 'dark') document.body.classList.add('dark-mode');
}

  // Form validation—Bootstrap style
  document.querySelectorAll('form.needs-validation').forEach(form => {
    form.addEventListener('submit', function (event) {
      if (!form.checkValidity()) {
        event.preventDefault();
        event.stopPropagation();
        showToast("Please fill the required fields", "danger");
      }
      form.classList.add('was-validated');
    }, false);
  });

  // Animation on cards and trip list (staggered)
  document.querySelectorAll('.animate-fadein').forEach((el, i) => {
    el.style.animationDelay = (i * 0.07) + 's';
  });

  // Focus-visible for better accessibility
  document.body.addEventListener('keyup', function(e) {
    if (e.key === 'Tab') document.body.classList.add('focus-visible');
  });
});

