from flask import Flask, render_template, request, redirect, session, jsonify, send_file, url_for
from geopy.geocoders import Nominatim
from fpdf import FPDF
from werkzeug.utils import secure_filename
from functools import wraps
import os
import json
import uuid
import datetime

# -------------------------
# Config
# -------------------------
app = Flask(__name__)
app.secret_key = "my_secret_key_2025"  # change for production

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
UPLOAD_DIR = os.path.join(BASE_DIR, "static", "uploads")
DATA_FILE = os.path.join(DATA_DIR, "users.json")

os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(UPLOAD_DIR, exist_ok=True)

# geopy locator (single instance)
geolocator = Nominatim(user_agent="my_travel_diary_app_boot")

# Admin credentials (simple embedded for demo — change before production)
ADMIN_EMAIL = "admin@mydiary.local"
ADMIN_PASSWORD = "admin1234"


# -------------------------
# Helpers
# -------------------------
def load_users():
    """Load users JSON file (returns dict). Creates sample demo user if missing."""
    if not os.path.exists(DATA_FILE):
        # create a default demo user for convenience
        demo = {
            "demo@example.com": {
                "name": "Demo Traveler",
                "email": "demo@example.com",
                "password": "demo1234",
                "joined": datetime.date.today().isoformat(),
                "trips": []
            }
        }
        with open(DATA_FILE, "w", encoding="utf-8") as f:
            json.dump(demo, f, indent=2, ensure_ascii=False)
        return demo
    with open(DATA_FILE, "r", encoding="utf-8") as f:
        try:
            return json.load(f)
        except json.JSONDecodeError:
            return {}


def save_users(users):
    with open(DATA_FILE, "w", encoding="utf-8") as f:
        json.dump(users, f, indent=2, ensure_ascii=False)


def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not session.get("user"):
            return redirect(url_for("auth"))
        return f(*args, **kwargs)
    return decorated


def admin_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if not session.get("is_admin"):
            return redirect(url_for("auth"))
        return f(*args, **kwargs)
    return decorated


def current_user():
    users = load_users()
    email = session.get("user")
    return users.get(email) if email else None


# -------------------------
# Auth (login/register)
# -------------------------
@app.route("/", methods=["GET"])
def auth():
    if session.get("user"):
        return redirect(url_for("dashboard"))
    msg = session.pop("_msg", None)
    error = session.pop("_err", None)
    return render_template("auth.html", msg=msg, error=error)


@app.route("/register", methods=["POST"])
def register():
    name = request.form.get("name", "").strip() or "Traveler"
    email = request.form.get("email", "").strip().lower()
    password = request.form.get("password", "").strip()
    if not email or not password:
        session["_err"] = "Provide email and password."
        return redirect(url_for("auth"))
    users = load_users()
    if email in users:
        session["_err"] = "Email already registered. Please login."
        return redirect(url_for("auth"))

    users[email] = {
        "name": name,
        "email": email,
        "password": password,
        "joined": datetime.date.today().isoformat(),
        "trips": []
    }
    save_users(users)
    session["_msg"] = "Registration successful — please login."
    return redirect(url_for("auth"))


@app.route("/login", methods=["POST"])
def login():
    email = request.form.get("email", "").strip().lower()
    password = request.form.get("password", "").strip()
    # admin login check
    if email == ADMIN_EMAIL and password == ADMIN_PASSWORD:
        session["user"] = ADMIN_EMAIL
        session["is_admin"] = True
        return redirect(url_for("admin_panel"))
    users = load_users()
    if email in users and users[email]["password"] == password:
        session["user"] = email
        session["is_admin"] = False
        return redirect(url_for("dashboard"))
    session["_err"] = "Invalid credentials. Try again."
    return redirect(url_for("auth"))


@app.route("/logout")
def logout():
    session.pop("user", None)
    session.pop("is_admin", None)
    return redirect(url_for("auth"))


# -------------------------
# Dashboard & trip routes
# -------------------------
@app.route("/dashboard")
@login_required
def dashboard():
    user = current_user()
    if not user:
        return redirect(url_for("auth"))
    trips = user.get("trips", [])
    # compute total_expense and fav_count safely
    try:
        total_expense = sum(float(t.get("expense") or 0) for t in trips)
    except Exception:
        total_expense = 0
    fav_count = sum(1 for t in trips if t.get("favorite"))
    return render_template("dashboard.html", user=user, trips=trips, total_expense=total_expense, fav_count=fav_count)


@app.route("/add_trip", methods=["POST"])
@login_required
def add_trip():
    user = current_user()
    if not user:
        return redirect(url_for("auth"))

    # Accept fields used in your dashboard.html template
    country = request.form.get("country", "").strip().title()
    city = request.form.get("city", "").strip()
    start_date = request.form.get("start_date", "").strip()
    end_date = request.form.get("end_date", "").strip()
    expense = request.form.get("expense", "0").strip() or "0"
    try:
        expense = float(expense)
    except Exception:
        expense = 0.0
    rating = int(request.form.get("rating", "0") or 0)
    companions = request.form.get("companions", "").strip()
    checklist = request.form.get("checklist", "").strip()
    memory = request.form.get("memory", "").strip()
    notes = request.form.get("notes", "").strip()
    favorite = True if request.form.get("favorite") in ("on", "true", "1") else False
    ai_summary = request.form.get("ai_summary", "").strip()

    # handle uploaded photos (multiple)
    saved_files = []
    files = request.files.getlist("photos")
    for f in files:
        if f and f.filename:
            filename = secure_filename(f"{uuid.uuid4().hex}_{f.filename}")
            path = os.path.join(UPLOAD_DIR, filename)
            f.save(path)
            saved_files.append(filename)

    # geocode (best-effort)
    lat = lon = None
    if country:
        try:
            loc = geolocator.geocode(country, timeout=10)
            if loc:
                lat, lon = loc.latitude, loc.longitude
        except Exception:
            lat = lon = None

    trip = {
        "id": uuid.uuid4().hex,
        "country": country,
        "city": city,
        "start_date": start_date,
        "end_date": end_date,
        "expense": expense,
        "rating": rating,
        "companions": companions,
        "checklist": checklist,
        "memory": memory,
        "notes": notes,
        "ai_summary": ai_summary,
        "photos": saved_files,
        "lat": lat,
        "lon": lon,
        "favorite": favorite,
        "created": datetime.datetime.now().isoformat()
    }

    users = load_users()
    users[session["user"]]["trips"].append(trip)
    save_users(users)
    return redirect(url_for("dashboard"))


@app.route("/delete_trip/<trip_id>", methods=["POST"])
@login_required
def delete_trip(trip_id):
    users = load_users()
    email = session.get("user")
    if not email or email not in users:
        return redirect(url_for("auth"))
    trips = users[email]["trips"]
    # remove associated photos from uploads
    to_delete = [t for t in trips if t.get("id") == trip_id]
    for t in to_delete:
        for p in t.get("photos", []):
            ppath = os.path.join(UPLOAD_DIR, p)
            try:
                if os.path.exists(ppath):
                    os.remove(ppath)
            except Exception:
                pass
    users[email]["trips"] = [t for t in trips if t.get("id") != trip_id]
    save_users(users)
    return redirect(url_for("dashboard"))


@app.route("/toggle_fav/<trip_id>", methods=["POST"])
@login_required
def toggle_fav(trip_id):
    users = load_users()
    email = session.get("user")
    if not email or email not in users:
        return redirect(url_for("auth"))
    for t in users[email]["trips"]:
        if t.get("id") == trip_id:
            t["favorite"] = not t.get("favorite", False)
            break
    save_users(users)
    return redirect(url_for("dashboard"))


# -------------------------
# Map & analytics pages
# -------------------------
@app.route("/map")
@login_required
def map_page():
    user = current_user()
    if not user:
        return redirect(url_for("auth"))
    return render_template("map.html", trips=user.get("trips", []), user=user)


@app.route("/analytics")
@login_required
def analytics_page():
    user = current_user()
    if not user:
        return redirect(url_for("auth"))
    trips = user.get("trips", [])
    return render_template("analytics.html", trips=trips, user=user)


@app.route("/api/trips")
@login_required
def api_trips():
    user = current_user()
    if not user:
        return jsonify([])
    return jsonify(user.get("trips", []))


# -------------------------
# Export JSON / PDF
# -------------------------
# Keep the template url_for names used in templates: export_json and export_pdf
@app.route("/export_json")
@login_required
def export_json():
    user = current_user()
    if not user:
        return redirect(url_for("auth"))
    out_path = os.path.join(DATA_DIR, f"{user['email']}_diary.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(user, f, indent=2, ensure_ascii=False)
    return send_file(out_path, as_attachment=True)


@app.route("/export_pdf")
@login_required
def export_pdf():
    user = current_user()
    if not user:
        return redirect(url_for("auth"))
    pdf = FPDF()
    pdf.add_page()
    # Use correct path for your font
    font_path = os.path.join(app.root_path, "static", "fonts", "dejavu-fonts-ttf-2.37", "ttf", "DejaVuSans.ttf")
    pdf.add_font('DejaVu', '', font_path, uni=True)
    pdf.set_font("DejaVu", '', 16)
    pdf.cell(0, 10, f"Travel Diary — {user.get('name')}", ln=True, align="C")
    pdf.ln(6)
    pdf.set_font("DejaVu", '', 12)
    for t in user.get("trips", []):
        header = f"{t.get('country', '')}{(' - ' + t.get('city')) if t.get('city') else ''}"
        pdf.set_font("DejaVu", '', 12)
        pdf.cell(0, 8, header, ln=True)
        pdf.set_font("DejaVu", '', 11)
        def safe(s): return str(s or '').replace('\u2014', '-')
        pdf.multi_cell(
            0, 7,
            f"{safe(t.get('start_date',''))} to {safe(t.get('end_date',''))}\n"
            f"Expense: ${safe(t.get('expense','0'))}\n"
            f"Rating: {safe(t.get('rating',''))}\n"
            f"Notes: {safe(t.get('notes',''))}\n"
            f"AI Summary: {safe(t.get('ai_summary',''))}"
        )
        pdf.ln(2)
    path = os.path.join(DATA_DIR, f"{user['email']}_diary.pdf")
    pdf.output(path)
    return send_file(path, as_attachment=True)




# -------------------------
# Admin panel
# -------------------------
@app.route("/admin")
@admin_required
def admin_panel():
    users = load_users()
    return render_template("admin.html", users=users)


@app.route("/admin/user/<email>")
@admin_required
def admin_user_view(email):
    users = load_users()
    user = users.get(email)
    if not user:
        return "User not found", 404
    # reuse dashboard template to show that user's trips (admin view)
    total_expense = sum(float(t.get("expense") or 0) for t in user.get("trips", []))
    fav_count = sum(1 for t in user.get("trips", []) if t.get("favorite"))
    return render_template("dashboard.html", user=user, trips=user.get("trips", []), total_expense=total_expense, fav_count=fav_count)


# -------------------------
# Utility endpoint for debug / client
# -------------------------
@app.route("/get_user_data")
@login_required
def get_user_data():
    user = current_user()
    if not user:
        return jsonify({})
    return jsonify(user)


# -------------------------
# Run
# -------------------------
if __name__ == "__main__":
    app.run(debug=True)
