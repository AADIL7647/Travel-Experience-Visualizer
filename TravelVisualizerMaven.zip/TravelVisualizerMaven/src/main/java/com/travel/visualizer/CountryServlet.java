package com.travel.visualizer;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import jakarta.servlet.annotation.WebServlet;
import java.io.*;

@WebServlet("/CountryServlet")
public class CountryServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String[] countries = new String[5];
        for (int i = 0; i < 5; i++) {
            String input = request.getParameter("country" + (i + 1));
            countries[i] = input != null ? input.trim() : "";
        }

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        out.println("<html><head><title>Map</title>");
        out.println("<script>");
        out.println("const countries = " + arrayToJSArray(countries) + ";");
        out.println("</script>");
        out.println("<script src='https://unpkg.com/leaflet@1.9.3/dist/leaflet.js'></script>");
        out.println("<link rel='stylesheet' href='https://unpkg.com/leaflet@1.9.3/dist/leaflet.css'/>");
        out.println("<style> body { font-family: Arial; margin: 20px; } #map { height: 500px; margin-top: 20px; } </style>");
        out.println("</head><body>");
        out.println("<h2>Countries You Visited:</h2>");
        out.println("<ul>");
        for (String country : countries) {
            if (!country.isEmpty()) {
                out.println("<li>" + country + "</li>");
            }
        }
        out.println("</ul>");
        out.println("<div id='map'></div>");
        out.println("<script>");
        out.println(getLeafletJS());
        out.println("</script>");
        out.println("</body></html>");
    }

    private String arrayToJSArray(String[] arr) {
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < arr.length; i++) {
            String country = arr[i] != null ? arr[i].replace("\"", "") : "";
            sb.append("\"").append(country).append("\"");
            if (i < arr.length - 1) sb.append(", ");
        }
        sb.append("]");
        return sb.toString();
    }

    private String getLeafletJS() {
        return """
            const map = L.map('map').setView([20, 0], 2);
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: 'Map data © <a href="https://openstreetmap.org">OpenStreetMap</a> contributors',
            }).addTo(map);

            const countryCoords = {
                "India": [20.5937, 78.9629],
                "Pakistan": [30.3753, 69.3451],
                "China": [35.8617, 104.1954],
                "Afghanistan": [33.9391, 67.7100],
                "Bangladesh": [23.6850, 90.3563],
                "USA": [37.0902, -95.7129],
                "UK": [55.3781, -3.4360],
                "France": [46.2276, 2.2137],
                "Germany": [51.1657, 10.4515],
                "Japan": [36.2048, 138.2529]
            };

            countries.forEach(country => {
                const coord = countryCoords[country];
                if (coord) {
                    L.circleMarker(coord, {
                        radius: 8,
                        color: "orange",
                        fillColor: "#f03",
                        fillOpacity: 0.5
                    }).addTo(map).bindPopup(country);
                }
            });
        """;
    }
}
